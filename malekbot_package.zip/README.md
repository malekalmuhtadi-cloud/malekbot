# MalekBot - German & English version
Simple AI chatbot for small businesses (Deutsch & English).
Package includes:
- backend/ (Node/Express)
- frontend/ (Vite + React)
- marketing materials and contract templates

## Quick start (local)
1. Backend:
   - cd backend
   - npm install
   - create .env with OPENAI_API_KEY
   - npm start
2. Frontend:
   - cd frontend
   - npm install
   - npm run dev

Frontend expects backend proxy at /api when deployed (use Vercel + Render or configure proxy in dev).

## Notes
- This is a starter package. Replace in-memory store with a database for production.
- Do not commit your OpenAI API key.
