// server.js
// Simple Node/Express backend for MalekBot (memory store, OpenAI proxy)
// Requirements: Node 18+, npm install express axios dotenv cors body-parser uuid
import express from "express";
import cors from "cors";
import axios from "axios";
import dotenv from "dotenv";
import bodyParser from "body-parser";
import { v4 as uuidv4 } from "uuid";

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

const OPENAI_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini";

let clients = {}; // in-memory store; replace with DB in production

app.get("/api/health", (req, res) => res.json({ ok: true, app: "MalekBot" }));

app.post("/api/admin/create-client", (req, res) => {
  const { name, slug, language = "en", info = {} } = req.body;
  const id = uuidv4();
  clients[id] = { id, name, slug, language, info, active: true, createdAt: Date.now() };
  return res.json({ ok: true, client: clients[id] });
});

app.post("/api/admin/toggle/:id", (req, res) => {
  const id = req.params.id;
  if (!clients[id]) return res.status(404).json({ error: "client not found" });
  clients[id].active = !clients[id].active;
  return res.json({ ok: true, client: clients[id] });
});

app.get("/api/client/:slug", (req, res) => {
  const slug = req.params.slug;
  const client = Object.values(clients).find(c => c.slug === slug);
  if (!client) return res.status(404).json({ error: "not found" });
  return res.json({ client });
});

app.post("/api/chat/:slug", async (req, res) => {
  try {
    const slug = req.params.slug;
    const client = Object.values(clients).find(c => c.slug === slug);
    if (!client) return res.status(404).json({ error: "client not found" });
    if (!client.active) return res.status(403).json({ error: "subscription inactive" });

    const { messages } = req.body;
    if (!OPENAI_KEY) return res.status(500).json({ error: "server missing OpenAI key" });

    const systemPrompt = {
      role: "system",
      content: `You are MalekBot for ${client.name}. Answer clearly in English or German depending on user language. Keep responses concise and business-like.`
    };

    const payloadMessages = [systemPrompt, ...(messages || [])];

    const resp = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: OPENAI_MODEL,
        messages: payloadMessages,
        max_tokens: 600,
        temperature: 0.2
      },
      { headers: { Authorization: `Bearer ${OPENAI_KEY}` } }
    );

    return res.json(resp.data);
  } catch (err) {
    console.error(err?.response?.data || err.message);
    return res.status(500).json({ error: "OpenAI error", detail: err?.response?.data || err.message });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`MalekBot server listening on ${PORT}`));
